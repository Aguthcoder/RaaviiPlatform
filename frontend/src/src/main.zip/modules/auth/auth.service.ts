import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { UsersService } from '../users/users.service';
import { ProfilesService } from '../profiles/profiles.service';
import { TestResultsService } from '../test-results/test-results.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import * as bcrypt from 'bcrypt';

@Injectable()
export class AuthService {
  constructor(
    private usersService: UsersService,
    private profilesService: ProfilesService,
    private testResultsService: TestResultsService,
    private jwtService: JwtService,
  ) {}

  async register(registerDto: RegisterDto) {
    const user = await this.usersService.create(registerDto);
    await this.profilesService.create(user.id);

    const token = this.generateToken(user.id, user.email);

    return {
      access_token: token,
      token_type: 'Bearer',
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        is_verified: user.is_verified,
        profile_completed: false,
      },
    };
  }

  async login(loginDto: LoginDto) {
    const user = await this.usersService.findByEmail(loginDto.email);

    if (!user) {
      throw new UnauthorizedException('ایمیل یا رمز عبور اشتباه است');
    }

    const isPasswordValid = await bcrypt.compare(
      loginDto.password,
      user.password_hash,
    );

    if (!isPasswordValid) {
      throw new UnauthorizedException('ایمیل یا رمز عبور اشتباه است');
    }

    if (user.is_banned) {
      throw new UnauthorizedException('حساب کاربری شما مسدود شده است');
    }

    await this.usersService.updateLastLogin(user.id);

    const profile = await this.profilesService.findByUserId(user.id);
    const token = this.generateToken(user.id, user.email);

    return {
      access_token: token,
      token_type: 'Bearer',
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        is_verified: user.is_verified,
        profile_completed: profile?.profile_completion_percentage === 100,
      },
    };
  }

  async getProfile(userId: string) {
    const user = await this.usersService.findById(userId);
    const profile = await this.profilesService.findByUserId(userId);
    const testResults = await this.testResultsService.findByUserId(userId);

    return {
      id: user.id,
      email: user.email,
      role: user.role,
      credits_balance: user.credits_balance,
      profile: profile
        ? {
            first_name: profile.first_name,
            last_name: profile.last_name,
            city: profile.city,
            bio: profile.bio,
            profile_completion_percentage: profile.profile_completion_percentage,
          }
        : null,
      is_profile_complete: profile?.profile_completion_percentage === 100,
      is_test_taken: testResults && testResults.length > 0,
    };
  }

  private generateToken(userId: string, email: string): string {
    const payload = { sub: userId, email };
    return this.jwtService.sign(payload);
  }
}
