import { IsEmail, IsString } from 'class-validator';

export class LoginDto {
  @IsEmail({}, { message: 'ایمیل معتبر وارد کنید' })
  email: string;

  @IsString()
  password: string;
}
