import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  OneToOne,
  OneToMany,
} from 'typeorm';
import { Profile } from '../../profiles/entities/profile.entity';
import { Booking } from '../../bookings/entities/booking.entity';
import { Payment } from '../../payments/entities/payment.entity';
import { Match } from '../../matches/entities/match.entity';
import { Message } from '../../messages/entities/message.entity';
import { Feedback } from '../../feedbacks/entities/feedback.entity';

@Entity('users')
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  email: string;

  @Column()
  password_hash: string;

  @Column({ unique: true, nullable: true })
  phone_number: string;

  @Column({ type: 'bigint', unique: true, nullable: true })
  telegram_id: string;

  @Column({ nullable: true })
  telegram_username: string;

  @Column({ default: 'user' })
  role: string;

  @Column({ default: 0 })
  credits_balance: number;

  @Column({ default: false })
  is_verified: boolean;

  @Column({ default: false })
  is_banned: boolean;

  @Column({ default: 'onboarding' })
  current_fsm_state: string;

  @Column({ type: 'timestamp', nullable: true })
  last_login: Date;

  @Column({ default: 0 })
  login_count: number;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @OneToOne(() => Profile, (profile) => profile.user, { cascade: true })
  profile: Profile;

  @OneToMany(() => Booking, (booking) => booking.user)
  bookings: Booking[];

  @OneToMany(() => Payment, (payment) => payment.user)
  payments: Payment[];

  @OneToMany(() => Match, (match) => match.user)
  initiated_matches: Match[];

  @OneToMany(() => Match, (match) => match.target_user)
  received_matches: Match[];

  @OneToMany(() => Message, (message) => message.sender)
  messages: Message[];

  @OneToMany(() => Feedback, (feedback) => feedback.user)
  feedbacks_given: Feedback[];

  @OneToMany(() => Feedback, (feedback) => feedback.target)
  feedbacks_received: Feedback[];
}
