import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Event } from './entities/event.entity';
import { CreateEventDto } from './dto/create-event.dto';

@Injectable()
export class EventsService {
  constructor(
    @InjectRepository(Event)
    private eventsRepository: Repository<Event>,
  ) {}

  async create(createEventDto: CreateEventDto): Promise<Event> {
    const event = this.eventsRepository.create(createEventDto);
    return await this.eventsRepository.save(event);
  }

  async findAll(query: {
    page?: number;
    limit?: number;
    city?: string;
    event_type?: string;
  }) {
    const page = query.page || 1;
    const limit = query.limit || 10;
    const skip = (page - 1) * limit;

    const queryBuilder = this.eventsRepository
      .createQueryBuilder('event')
      .where('event.is_active = :isActive', { isActive: true });

    if (query.city) {
      queryBuilder.andWhere('event.location ILIKE :city', {
        city: `%${query.city}%`,
      });
    }

    if (query.event_type) {
      queryBuilder.andWhere('event.event_type = :type', {
        type: query.event_type,
      });
    }

    const [data, total] = await queryBuilder
      .orderBy('event.start_date', 'ASC')
      .skip(skip)
      .take(limit)
      .getManyAndCount();

    const eventsWithSlots = data.map((event) => ({
      ...event,
      available_slots: event.capacity - event.current_bookings,
    }));

    return {
      data: eventsWithSlots,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async findOne(id: string): Promise<Event> {
    const event = await this.eventsRepository.findOne({
      where: { id },
    });

    if (!event) {
      throw new NotFoundException('رویداد یافت نشد');
    }

    return event;
  }

  async update(id: string, data: Partial<Event>): Promise<Event> {
    const event = await this.findOne(id);
    Object.assign(event, data);
    return await this.eventsRepository.save(event);
  }

  async incrementBookings(id: string): Promise<void> {
    await this.eventsRepository.increment({ id }, 'current_bookings', 1);
  }

  async decrementBookings(id: string): Promise<void> {
    await this.eventsRepository.decrement({ id }, 'current_bookings', 1);
  }
}
