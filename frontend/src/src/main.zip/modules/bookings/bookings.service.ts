import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ConflictException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Booking } from './entities/booking.entity';
import { EventsService } from '../events/events.service';
import { CreateBookingDto } from './dto/create-booking.dto';

@Injectable()
export class BookingsService {
  constructor(
    @InjectRepository(Booking)
    private bookingsRepository: Repository<Booking>,
    private eventsService: EventsService,
  ) {}

  async create(userId: string, createBookingDto: CreateBookingDto) {
    const event = await this.eventsService.findOne(createBookingDto.event_id);

    if (event.current_bookings >= event.capacity) {
      throw new BadRequestException('ظرفیت رویداد تکمیل شده است');
    }

    const existingBooking = await this.bookingsRepository.findOne({
      where: {
        event_id: createBookingDto.event_id,
        user_id: userId,
        status: 'confirmed',
      },
    });

    if (existingBooking) {
      throw new ConflictException('شما قبلا این رویداد را رزرو کرده‌اید');
    }

    const bookingCode = this.generateBookingCode();
    const lockedUntil = new Date();
    lockedUntil.setMinutes(lockedUntil.getMinutes() + 5);

    const booking = this.bookingsRepository.create({
      event_id: createBookingDto.event_id,
      user_id: userId,
      status: 'pending',
      payment_status: 'unpaid',
      booking_code: bookingCode,
      locked_until: lockedUntil,
      amount_paid: event.price,
    });

    const savedBooking = await this.bookingsRepository.save(booking);

    return {
      booking: savedBooking,
      payment: {
        payment_url: `http://localhost:3000/payments/gateway?booking_id=${savedBooking.id}`,
        authority: 'A' + savedBooking.id.replace(/-/g, '').substring(0, 36),
      },
    };
  }

  async findByUserId(userId: string, query?: { status?: string }) {
    const queryBuilder = this.bookingsRepository
      .createQueryBuilder('booking')
      .leftJoinAndSelect('booking.event', 'event')
      .where('booking.user_id = :userId', { userId });

    if (query?.status) {
      queryBuilder.andWhere('booking.status = :status', {
        status: query.status,
      });
    }

    const bookings = await queryBuilder
      .orderBy('booking.created_at', 'DESC')
      .getMany();

    return {
      data: bookings.map((booking) => ({
        id: booking.id,
        event: {
          id: booking.event.id,
          title: booking.event.title,
          image_url: booking.event.image_url,
          start_date: booking.event.start_date,
          location: booking.event.location,
        },
        status: booking.status,
        payment_status: booking.payment_status,
        booking_code: booking.booking_code,
        amount_paid: booking.amount_paid,
        confirmation_code: booking.confirmation_code,
        attended: booking.attended,
        created_at: booking.created_at,
        confirmed_at: booking.confirmed_at,
      })),
    };
  }

  async confirmBooking(id: string): Promise<Booking> {
    const booking = await this.bookingsRepository.findOne({
      where: { id },
    });

    if (!booking) {
      throw new NotFoundException('رزرو یافت نشد');
    }

    booking.status = 'confirmed';
    booking.payment_status = 'paid';
    booking.confirmed_at = new Date();
    booking.confirmation_code = this.generateConfirmationCode();

    await this.eventsService.incrementBookings(booking.event_id);

    return await this.bookingsRepository.save(booking);
  }

  async cancelBooking(id: string, userId: string, reason?: string) {
    const booking = await this.bookingsRepository.findOne({
      where: { id, user_id: userId },
    });

    if (!booking) {
      throw new NotFoundException('رزرو یافت نشد');
    }

    if (booking.status !== 'confirmed') {
      throw new BadRequestException('فقط رزروهای تایید شده قابل لغو هستند');
    }

    booking.status = 'cancelled';
    booking.cancellation_reason = reason;
    booking.cancelled_at = new Date();

    await this.eventsService.decrementBookings(booking.event_id);

    return await this.bookingsRepository.save(booking);
  }

  private generateBookingCode(): string {
    const prefix = 'RV';
    const random = Math.random().toString(36).substring(2, 8).toUpperCase();
    return `${prefix}-${random}`;
  }

  private generateConfirmationCode(): string {
    const prefix = 'CONFIRM';
    const random = Math.random().toString(36).substring(2, 9).toUpperCase();
    return `${prefix}-${random}`;
  }
}
