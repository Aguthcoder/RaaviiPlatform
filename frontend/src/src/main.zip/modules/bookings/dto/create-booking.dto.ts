import { IsUUID, IsString } from 'class-validator';

export class CreateBookingDto {
  @IsUUID()
  event_id: string;

  @IsString()
  payment_method: string;
}
