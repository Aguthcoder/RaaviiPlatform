import {
  Controller,
  Get,
  Post,
  Patch,
  Body,
  Param,
  Query,
  UseGuards,
  Request,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { BookingsService } from './bookings.service';
import { CreateBookingDto } from './dto/create-booking.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@Controller('bookings')
@UseGuards(JwtAuthGuard)
export class BookingsController {
  constructor(private bookingsService: BookingsService) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  async create(@Request() req, @Body() createBookingDto: CreateBookingDto) {
    return await this.bookingsService.create(req.user.id, createBookingDto);
  }

  @Get('my')
  async getMyBookings(@Request() req, @Query('status') status?: string) {
    return await this.bookingsService.findByUserId(req.user.id, { status });
  }

  @Patch(':id/cancel')
  async cancelBooking(
    @Request() req,
    @Param('id') id: string,
    @Body('cancellation_reason') reason?: string,
  ) {
    const booking = await this.bookingsService.cancelBooking(
      id,
      req.user.id,
      reason,
    );

    return {
      message: 'رزرو با موفقیت لغو شد',
      booking: {
        id: booking.id,
        status: booking.status,
        cancelled_at: booking.cancelled_at,
      },
      refund: {
        amount: booking.amount_paid,
        status: 'pending',
        estimated_date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    };
  }
}
