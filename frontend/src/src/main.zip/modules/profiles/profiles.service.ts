import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Profile } from './entities/profile.entity';
import { UpdateProfileDto } from './dto/update-profile.dto';

@Injectable()
export class ProfilesService {
  constructor(
    @InjectRepository(Profile)
    private profilesRepository: Repository<Profile>,
  ) {}

  async create(userId: string): Promise<Profile> {
    const profile = this.profilesRepository.create({
      user_id: userId,
      profile_completion_percentage: 0,
    });

    return await this.profilesRepository.save(profile);
  }

  async findByUserId(userId: string): Promise<Profile | null> {
    return await this.profilesRepository.findOne({
      where: { user_id: userId },
    });
  }

  async update(userId: string, data: UpdateProfileDto): Promise<Profile> {
    const profile = await this.findByUserId(userId);

    if (!profile) {
      throw new NotFoundException('پروفایل یافت نشد');
    }

    Object.assign(profile, data);
    profile.profile_completion_percentage = this.calculateCompletion(profile);

    return await this.profilesRepository.save(profile);
  }

  async completeProfile(userId: string): Promise<Profile> {
    const profile = await this.findByUserId(userId);

    if (!profile) {
      throw new NotFoundException('پروفایل یافت نشد');
    }

    profile.profile_completion_percentage = 100;

    return await this.profilesRepository.save(profile);
  }

  private calculateCompletion(profile: Profile): number {
    let score = 0;
    const fields = [
      'first_name',
      'last_name',
      'gender',
      'birth_date',
      'city',
      'marital_status',
      'education_level',
      'bio',
    ];

    fields.forEach((field) => {
      if (profile[field]) {
        score += 100 / fields.length;
      }
    });

    return Math.round(score);
  }
}
